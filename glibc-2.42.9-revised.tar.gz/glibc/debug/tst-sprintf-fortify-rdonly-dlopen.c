#include "tst-sprintf-fortify-rdonly-mod.c"
