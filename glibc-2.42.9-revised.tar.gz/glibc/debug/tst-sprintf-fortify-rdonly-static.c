#include "tst-sprintf-fortify-rdonly.c"
