#define DO_STATIC_TEST 0
#include "tst-ctype-tls-skeleton.c"
