#define DO_STATIC_TEST 1
#include "tst-ctype-tls-skeleton.c"
