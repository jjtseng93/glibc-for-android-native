#undef _GNU_SOURCE

#include <test-assert.c>
